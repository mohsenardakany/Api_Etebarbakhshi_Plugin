const pluginId = 'personal-notes';
const pending = new Map();
let requestSequence = 0;

export function request(action, values = {}) {
  return new Promise((resolve, reject) => {
    const requestId = `${Date.now().toString(36)}-${(++requestSequence).toString(36)}`;
    pending.set(requestId, { resolve, reject });
    window.parent.postMessage({ channel: 'accredit-plugin', pluginId, requestId, action, ...values }, '*');
  });
}

window.addEventListener('message', event => {
  if (event.source !== window.parent) return;
  const message = event.data;
  if (message?.channel !== 'accredit-plugin-response' || message.pluginId !== pluginId) return;
  const callbacks = pending.get(message.requestId);
  if (!callbacks) return;
  pending.delete(message.requestId);
  if (message.ok) callbacks.resolve(message.result);
  else callbacks.reject(new Error(message.error || 'Plugin request failed.'));
});

export const listNotes = () => request('data.list');
export const addNote = text => request('data.create', { recordKey: `note-${Date.now()}`, data: { text } });
export const deleteNote = id => request('data.delete', { recordId: id });